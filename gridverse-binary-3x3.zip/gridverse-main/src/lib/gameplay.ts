import type { GameKind } from "@/data/games";
import { createMatrixPuzzle, createOddPuzzle, createTimeline, shuffle } from "@/lib/puzzle-engine";

export type ChoiceDisplay = "sequence" | "tiles" | "matrix" | "palette" | "network" | "board" | "spatial";

export type ChoicePuzzle = {
  id: string;
  prompt: string;
  clue: string;
  options: string[];
  answer: number;
  display: ChoiceDisplay;
  visual: string[];
};

export const numberTarget = [
  1, 2, 3, 4,
  3, 4, 1, 2,
  2, 1, 4, 3,
  4, 3, 2, 1,
];

export const binaryTarget = [
  0, 1, 0,
  1, 0, 1,
  0, 1, 0,
];

export const nonogramTarget = [
  true, true, false, false,
  false, true, false, false,
  false, true, true, true,
  false, false, true, true,
];

export const mirrorTarget = [
  false, true, false, false,
  true, true, false, false,
  false, false, true, false,
  false, false, false, false,
];

export const hiddenPatternTarget = [
  false, true, true, false,
  true, false, false, true,
  false, false, true, true,
  false, false, false, false,
];

export const mineLocations = [2, 7, 11, 14];
export const pathSolution = [0, 1, 2, 3, 7, 11, 15];
export const flashTarget = [1, 5, 8, 12];
export const symbolTarget = [2, 6, 9, 14];
export const sequenceTarget = [1, 4, 7, 3];

export const symbols = ["◆", "●", "▲", "✚", "■", "✦"];

export function seededRandom(seed: number) {
  let value = Math.abs(seed) + 0x6d2b79f5;
  return () => {
    value += 0x6d2b79f5;
    let result = Math.imul(value ^ (value >>> 15), 1 | value);
    result ^= result + Math.imul(result ^ (result >>> 7), 61 | result);
    return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
  };
}

export type GridPuzzle = { target: number[]; givens: number[] };

export function getGridPuzzle(kind: "number-grid" | "binary-grid", tier: 1 | 2 | 3 | 4, stage = 1): GridPuzzle {
  const random = seededRandom((kind === "number-grid" ? 41 : 97) + tier * 17 + stage * 31);
  if (kind === "binary-grid") {
    // Every row and column starts from a mixed pattern, so no line can
    // contain three identical values. Permuting rows and columns preserves it.
    const rows = [
      [0, 1, 0],
      [1, 0, 1],
      [0, 1, 0],
    ];
    const rowOrder = shuffle([0, 1, 2], random);
    const columnOrder = shuffle([0, 1, 2], random);
    const target = rowOrder.flatMap((row) => columnOrder.map((column) => rows[row][column]));
    const clueCount = [6, 5, 4, 3][tier - 1];
    const givens = shuffle(Array.from({ length: 9 }, (_, index) => index), random).slice(0, clueCount).sort((a, b) => a - b);
    return { target, givens };
  }

  const base = [
    [1, 2, 3, 4],
    [3, 4, 1, 2],
    [2, 1, 4, 3],
    [4, 3, 2, 1],
  ];
  const symbolsOrder = [1, 2, 3, 4].sort(() => random() - 0.5);
  const target = Array.from({ length: 4 }, (_, row) => Array.from({ length: 4 }, (_, column) => symbolsOrder[base[(row + stage) % 4][column] - 1])).flat();
  const clueCount = [10, 8, 6, 4][tier - 1];
  const givens = Array.from({ length: 16 }, (_, index) => index).sort(() => random() - 0.5).slice(0, clueCount).sort((a, b) => a - b);
  return { target, givens };
}

export function isValidNumberGrid(cells: Array<number | boolean | null>) {
  if (cells.length !== 16 || cells.some((cell) => typeof cell !== "number" || cell < 1 || cell > 4)) return false;
  for (let line = 0; line < 4; line += 1) {
    const row = cells.slice(line * 4, line * 4 + 4);
    const column = [cells[line], cells[line + 4], cells[line + 8], cells[line + 12]];
    if (new Set(row as number[]).size !== 4 || new Set(column as number[]).size !== 4) return false;
  }
  return true;
}

export function isValidBinaryGrid(cells: Array<number | boolean | null>) {
  // Binary Grid is a 3×3 board. Every cell must be filled with 0 or 1,
  // and no row or column may contain three identical values in a row.
  if (cells.length !== 9 || cells.some((cell) => cell !== 0 && cell !== 1)) return false;
  const rows = Array.from({ length: 3 }, (_, row) => cells.slice(row * 3, row * 3 + 3) as number[]);
  const columns = Array.from({ length: 3 }, (_, column) => [cells[column], cells[column + 3], cells[column + 6]] as number[]);
  return [...rows, ...columns].every((line) => !(line[0] === line[1] && line[1] === line[2]));
}

export function isValidPath(path: number[], obstacles: number[], end = 15) {
  if (path.length < 2 || path[0] !== 0 || path[path.length - 1] !== end) return false;
  const blocked = new Set(obstacles);
  return new Set(path).size === path.length && path.every((cell, index) => cell >= 0 && cell < 16 && !blocked.has(cell) && (index === 0 || isAdjacent(path[index - 1], cell)));
}

export function isValidSwitchboard(lights: boolean[]) {
  return lights.length === 9 && lights.every(Boolean);
}

export function isValidMirrorSolution(cells: Array<number | boolean | null>, target: boolean[]) {
  return cells.length === target.length && cells.every((cell, index) => Boolean(cell) === target[index]);
}

export function isValidColorArrangement(cells: Array<number | boolean | null>) {
  const values = cells.slice(0, 4);
  return values.length === 4 && values.every((value): value is number => typeof value === "number") && new Set(values).size === 4 && values[0] === 0 && Math.abs(values.indexOf(1) - values.indexOf(2)) === 1 && Math.abs(values.indexOf(3) - values.indexOf(0)) > 1;
}

export function isValidNetwork(edges: Array<[number, number]>, selected: boolean[]) {
  return selected.filter(Boolean).length === 4 && [0, 1, 2, 3].every((node) => edges.reduce((degree, [from, to], index) => degree + (selected[index] && (from === node || to === node) ? 1 : 0), 0) === 2);
}

export function getLineClues(values: boolean[]) {
  const clues: number[] = [];
  let run = 0;
  values.forEach((value) => {
    if (value) run += 1;
    else if (run) { clues.push(run); run = 0; }
  });
  if (run) clues.push(run);
  return clues.length ? clues : [0];
}

export function getNonogramClues(target: boolean[]) {
  const size = Math.sqrt(target.length);
  const rows = Array.from({ length: size }, (_, row) => getLineClues(target.slice(row * size, (row + 1) * size)));
  const columns = Array.from({ length: size }, (_, column) => getLineClues(Array.from({ length: size }, (_, row) => target[row * size + column])));
  return { rows, columns };
}

export function matchesNonogramClues(cells: Array<number | boolean | null>, clues: ReturnType<typeof getNonogramClues>) {
  if (cells.length !== clues.rows.length ** 2 || cells.some((cell) => typeof cell !== "boolean")) return false;
  const actual = getNonogramClues(cells as boolean[]);
  return JSON.stringify(actual) === JSON.stringify(clues);
}

export function isValidNonogramSolution(cells: Array<number | boolean | null>, target: boolean[]) {
  return cells.length === target.length && cells.every((cell, index) => typeof cell === "boolean" && cell === target[index]);
}

export function revealSafeCells(start: number, clues: number[], mines: number[], revealed: number[], flags: number[]) {
  if (mines.includes(start) || flags.includes(start)) return revealed;
  const next = new Set(revealed);
  const queue = [start];
  while (queue.length) {
    const current = queue.shift()!;
    if (next.has(current) || mines.includes(current) || flags.includes(current)) continue;
    next.add(current);
    if (clues[current] !== 0) continue;
    const row = Math.floor(current / 4);
    const column = current % 4;
    for (let rowOffset = -1; rowOffset <= 1; rowOffset += 1) for (let columnOffset = -1; columnOffset <= 1; columnOffset += 1) {
      const nextRow = row + rowOffset;
      const nextColumn = column + columnOffset;
      if (nextRow >= 0 && nextRow < 4 && nextColumn >= 0 && nextColumn < 4) queue.push(nextRow * 4 + nextColumn);
    }
  }
  return [...next].sort((a, b) => a - b);
}

const baseChoicePuzzles: Record<string, ChoicePuzzle> = {
  "pattern-shift": { id: "pattern-shift-a", prompt: "Which frame comes next?", clue: "One new symbol is added to the right on every frame.", visual: ["◆", "◆ ●", "◆ ● ▲", "?"], options: ["◆ ● ▲ ■", "◆ ◆ ● ▲", "● ▲ ■", "◆ ▲ ● ■"], answer: 0, display: "sequence" },
  "odd-one-out": { id: "odd-one-out-a", prompt: "Which tile breaks the visual rule?", clue: "Three tiles rotate their highlight clockwise; one turns against it.", visual: ["◒", "◒", "◓", "◒"], options: ["Tile 1", "Tile 2", "Tile 3", "Tile 4"], answer: 2, display: "tiles" },
  "matrix-mystery": { id: "matrix-mystery-a", prompt: "Choose the missing cell in the relationship matrix.", clue: "The bottom row combines the shape from above with the color on the left.", visual: ["◆", "●", "▲", "?"], options: ["▲ + ●", "◆ + ▲", "● + ◆", "◆ + ●"], answer: 1, display: "matrix" },
  "color-logic": { id: "color-logic-a", prompt: "Which palette satisfies every clue?", clue: "Coral is first, indigo must touch mint, and gold cannot touch coral.", visual: ["indigo", "coral", "mint", "gold"], options: ["Indigo · Coral · Gold · Mint", "Coral · Indigo · Mint · Gold", "Gold · Coral · Indigo · Mint", "Indigo · Gold · Coral · Mint"], answer: 1, display: "palette" },
  "sequence-detective": { id: "sequence-detective-a", prompt: "What symbol completes the sequence?", clue: "The arrow rotates 90 degrees clockwise each step.", visual: ["↑", "→", "↓", "?"], options: ["↗", "←", "↙", "↑"], answer: 1, display: "sequence" },
  "region-rules": { id: "region-rules-a", prompt: "Choose the valid region split.", clue: "Every region must be connected and contain exactly one star.", visual: ["2 · ★ | 2 · ★", "3 · ★ | 1 · ★", "2 · ★ | 2 · ★", "1 · ★ | 3 · ★"], options: ["Vertical split", "Corner split", "Zig-zag split", "Horizontal split"], answer: 2, display: "board" },
  "rule-breaker": { id: "rule-breaker-a", prompt: "Which arrangement follows the hidden rule?", clue: "No two matching symbols may touch, even diagonally.", visual: ["◆ ● ▲", "◆ ◆ ▲", "● ▲ ●", "▲ ▲ ◆"], options: ["Arrangement A", "Arrangement B", "Arrangement C", "Arrangement D"], answer: 0, display: "tiles" },
  "mystery-network": { id: "mystery-network-a", prompt: "Which node completes every connection?", clue: "The missing node must connect to two blue nodes and one gold node.", visual: ["A — B", "B — C", "C — ?", "? — A"], options: ["Node A", "Node B", "Node C", "Node D"], answer: 1, display: "network" },
  "one-move": { id: "one-move-a", prompt: "Make exactly one strategic move to solve it.", clue: "Move the corner token into the only open lane.", visual: ["● · ·", "· ◆ ·", "· · ○"], options: ["Move left", "Move up", "Move down", "Move right"], answer: 2, display: "board" },
  "constraint-master": { id: "constraint-master-a", prompt: "Which option satisfies every constraint?", clue: "Blue is first, triangle is not last, and circle sits beside the star.", visual: ["● · ▲ · ★", "■ · ★ · ●", "★ · ● · ▲", "■ · ▲ · ●"], options: ["Option A", "Option B", "Option C", "Option D"], answer: 3, display: "board" },
};

export function getChoicePuzzle(kind: GameKind, stage = 1): ChoicePuzzle {
  if (kind === "daily-mystery") {
    const date = new Date();
    const seed = date.getUTCFullYear() * 372 + date.getUTCMonth() * 31 + date.getUTCDate();
    const options = ["Mira", "Jo", "Ren", "Sol"];
    const answer = seed % options.length;
    return { id: `daily-${date.toISOString().slice(0, 10)}`, prompt: "Which suspect has the complete alibi?", clue: "The correct timeline is gallery → cafe → observatory, with no overlap.", visual: ["Gallery · 08:10", "Cafe · 08:25", "Observatory · 08:40", "Archive · 08:55"], options: options.map((name, index) => `${name} · timeline ${index + 1}`), answer, display: "network" };
  }
  const puzzle = baseChoicePuzzles[kind] ?? baseChoicePuzzles["rule-breaker"];
  if (stage % 2 === 1 || kind !== "sequence-detective") return puzzle;
  return { ...puzzle, id: `${puzzle.id}-stage-${stage}`, clue: `${puzzle.clue} Stage ${stage} changes the order of the visual attributes.` };
}

export function isAdjacent(a: number, b: number, width = 4) {
  return Math.abs(a - b) === 1 && Math.floor(a / width) === Math.floor(b / width) || Math.abs(a - b) === width;
}


export function getSymbolLayout(stage: 1 | 2 | 3) {
  const positions = stage === 1 ? symbolTarget : stage === 2 ? [1, 4, 10, 15, 6] : [0, 5, 7, 10, 12, 15];
  return positions.reduce<Record<number, number>>((layout, position, index) => { layout[position] = (index + stage) % symbols.length; return layout; }, {});
}

export type PatternShiftPuzzle = { frames: number[][]; target: number[]; rule: string };
export type OddOneOutPuzzle = { items: Array<{ shape: string; fill: string; rotation: number }>; oddIndex: number; rule: string };
export type MatrixMysteryPuzzle = { cells: string[]; options: string[]; answer: number; rule: string };
export type SequenceDetectivePuzzle = { sequence: string[]; options: string[]; answer: number; rule: string };
export type DailyMysteryPuzzle = { id: string; items: string[]; answer: number[]; rule: string };

export function getPatternShiftPuzzle(stage = 1, level = 1): PatternShiftPuzzle {
  if (level > 1) {
    const transform = (cells: number[], frame: number) => cells.map(cell => {
      let row = Math.floor(cell / 4), column = cell % 4;
      if (level >= 3) for (let turn = 0; turn < frame % 4; turn++) [row, column] = [column, 3 - row];
      if (level === 4 && frame % 2 === 1) column = 3 - column;
      return row * 4 + column;
    });
    const frame = (index: number) => transform(Array.from({ length: (index + 1) * 2 }, (_, i) => (i + stage) % 16), index);
    return { frames: [frame(0), frame(1), frame(2)], target: frame(3), rule: `Add two consecutive cells to the untransformed pattern each frame${level >= 3 ? ', then rotate it one more quarter-turn clockwise' : ''}${level === 4 ? '; odd-numbered transformations (frames 2 and 4) also reflect horizontally after rotation' : ''}.` };
  }
  const patterns = [
    { frames: [[0], [0, 1], [0, 1, 2]], target: [0, 1, 2, 3], rule: "One adjacent cell is added from left to right." },
    { frames: [[0], [0, 5], [0, 5, 10]], target: [0, 5, 10, 15], rule: "The diagonal grows by one step on every frame." },
    { frames: [[0, 3], [1, 2, 4, 7], [0, 3, 5, 6, 8, 11]], target: [1, 2, 4, 7, 9, 10, 12, 13], rule: "The four-corner shape rotates clockwise and adds its next outer pair." },
  ];
  return patterns[(stage - 1) % patterns.length];
}

export function getOddOneOutPuzzle(seed = 1, level = 1) {
  return createOddPuzzle(level, seed);
}

export function getMatrixMysteryPuzzle(seed = 1, level = 1) {
  return createMatrixPuzzle(level, seed);
}

export function getSequenceDetectivePuzzle(stage = 1): SequenceDetectivePuzzle {
  const puzzles = [
    { sequence: ["↑", "→", "↓", "?"], options: ["↗", "←", "↙", "↑"], answer: 1, rule: "The arrow rotates 90 degrees clockwise." },
    { sequence: ["●", "●●", "●●●", "?"], options: ["●", "●●●●", "◆◆◆◆", "●●"], answer: 1, rule: "One symbol is added on every step." },
    { sequence: ["◆", "●", "◆◆", "●●", "?"], options: ["◆◆◆", "●●●", "◆", "●"], answer: 0, rule: "The symbol alternates while the count increases every two steps." },
  ];
  return puzzles[(stage - 1) % puzzles.length];
}

export function getDailyMysteryPuzzle(date = new Date(), level = 1): DailyMysteryPuzzle {
  const seed = date.getUTCFullYear() * 372 + date.getUTCMonth() * 31 + date.getUTCDate();
  return { id: `daily-${date.toISOString().slice(0, 10)}`, ...createTimeline(level, seed) };
}

export const choicePuzzles = baseChoicePuzzles;