import { describe, expect, it } from "vitest";
import { games } from "@/data/games";
import { getDailyMysteryPuzzle, getGridPuzzle, getMatrixMysteryPuzzle, getNonogramClues, getOddOneOutPuzzle, getPatternShiftPuzzle, getSequenceDetectivePuzzle, getChoicePuzzle, isValidBinaryGrid, isValidColorArrangement, isValidMirrorSolution, isValidNetwork, isValidNumberGrid, isValidPath, isValidSwitchboard, matchesNonogramClues, nonogramTarget, revealSafeCells } from "@/lib/gameplay";
import { validateMatrixPuzzle, validateOddPuzzle } from "@/lib/puzzle-engine";
import { getDailyPuzzleId, getDailyStreak } from "@/lib/progress";
import { getChallengeConfig } from "@/lib/difficulty";
import { getMineClues, getMineTargets, getMemoryTarget, getSceneTargets, getSequenceTarget, getSwitchSolution, getSwitchStart, toggleSwitch } from "@/lib/challenge-data";
import { calculateScore, getScoreBreakdown } from "@/lib/scoring";

const tiers = [1, 2, 3] as const;

describe("Gridverse puzzle rules", () => {
  it("generates valid number grids and keeps every clue consistent", () => {
    tiers.forEach((tier) => {
      const puzzle = getGridPuzzle("number-grid", tier, tier);
      expect(isValidNumberGrid(puzzle.target)).toBe(true);
      puzzle.givens.forEach((index) => expect(puzzle.target[index]).not.toBeNull());
    });
  });

  it("generates valid 3×3 binary grids with no triples", () => {
    tiers.forEach((tier) => {
      const puzzle = getGridPuzzle("binary-grid", tier, tier);
      expect(puzzle.target).toHaveLength(9);
      expect(puzzle.givens.length).toBeGreaterThan(0);
      expect(puzzle.givens.every((index) => index >= 0 && index < 9)).toBe(true);
      expect(isValidBinaryGrid(puzzle.target)).toBe(true);
    });
  });

  it("rejects incomplete, oversized, and triple-containing binary grids", () => {
    expect(isValidBinaryGrid([0, 0, 0, 1, 0, 1, 1, 1, 0])).toBe(false);
    expect(isValidBinaryGrid([0, 1, 0, 0, 1, 0, 0, 1, 0])).toBe(false); // third column is all zero
    expect(isValidBinaryGrid([0, 1, 0, 1, 0, 1, 0, 1, null])).toBe(false);
    expect(isValidBinaryGrid([0, 1, 0, 1, 0, 1, 0, 1, 0, 0])).toBe(false);
  });

  it("accepts any nonogram solution matching the calculated clues", () => {
    expect(matchesNonogramClues(nonogramTarget, getNonogramClues(nonogramTarget))).toBe(true);
  });

  it("keeps retained deterministic generators and validators aligned", () => {
    tiers.forEach((tier) => {
      const challenge = getChallengeConfig("mine-logic", "normal", tier);
      const mines = getMineTargets(challenge);
      const clues = getMineClues(challenge);
      expect(mines).toHaveLength(new Set(mines).size);
      expect(clues).toHaveLength(16);
      expect(getMemoryTarget("flash-grid", challenge)).toHaveLength(new Set(getMemoryTarget("flash-grid", challenge)).size);
      expect(getSequenceTarget(challenge)).toHaveLength(new Set(getSequenceTarget(challenge)).size);
      expect(getSceneTargets(challenge).changed.every((cell) => !getSceneTargets(challenge).before.includes(cell))).toBe(true);
      
      // Test switchboard generator/validator alignment
      const switchStart = getSwitchStart(challenge);
      const switchSolution = getSwitchSolution(challenge);
      // Apply the solution to the start state
      const testLights = [...switchStart];
      switchSolution.forEach(index => toggleSwitch(testLights, index));
      expect(isValidSwitchboard(testLights)).toBe(true);
    });
    expect(isValidPath([0, 1, 2, 3, 7, 11, 15], [5, 6, 10])).toBe(true);
    expect(isValidPath([0, 1, 5, 9, 15], [5, 6, 10])).toBe(false);
    expect(isValidSwitchboard(Array(9).fill(true))).toBe(true);
    expect(isValidSwitchboard(Array(8).fill(true))).toBe(false);
    expect(isValidMirrorSolution([true, false], [true, false])).toBe(true);
    expect(isValidColorArrangement([0, 1, 2, 3])).toBe(true);
    expect(isValidNetwork([[0, 1], [0, 2], [1, 3], [2, 3], [0, 3], [1, 2]], [true, false, false, true, true, true])).toBe(true);
  });

  it("expands zero-clue mine areas without revealing mines", () => {
    const revealed = revealSafeCells(0, [0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1], [2, 7, 11, 14], [], []);
    expect(revealed).not.toContain(2);
    expect(revealed).toContain(0);
  });

  it("generates distinct mechanics with valid deterministic answer data", () => {
    const pattern = getPatternShiftPuzzle(2);
    expect(pattern.target).toEqual([0, 5, 10, 15]);
    const odd = getOddOneOutPuzzle(2);
    expect(validateOddPuzzle(odd)).toBe(true);
    expect(validateMatrixPuzzle(getMatrixMysteryPuzzle(2))).toBe(true);
    expect(getSequenceDetectivePuzzle(3).options[getSequenceDetectivePuzzle(3).answer]).toBe("◆◆◆");
    const daily = getDailyMysteryPuzzle(new Date("2026-01-03T12:00:00Z"));
    expect(daily.answer.map(index => daily.items[index].split(" · ")[1])).toEqual(["08:00", "08:30", "09:00", "09:30"]);
  });

  it("keeps the daily puzzle stable for a date and changes the identifier next day", () => {
    const today = new Date("2026-01-03T12:00:00Z");
    const tomorrow = new Date("2026-01-04T12:00:00Z");
    expect(getDailyPuzzleId(today)).toBe(getDailyPuzzleId(today));
    expect(getDailyPuzzleId(today)).not.toBe(getDailyPuzzleId(tomorrow));
    expect(getChoicePuzzle("daily-mystery").id).toMatch(/^daily-/);
  });

  it("keeps score non-negative and exposes its penalty breakdown", () => {
    const breakdown = getScoreBreakdown("mine-logic", 900000, 100, 20, 10, "expert");
    expect(breakdown.total).toBeGreaterThanOrEqual(0);
    expect(calculateScore("mine-logic", 1000, 1, 0, 0, "hard")).toBeGreaterThan(calculateScore("mine-logic", 1000, 1, 2, 0, "hard"));
  });

  it("exposes only the curated release lineup", () => {
    expect(games).toHaveLength(14);
    expect(games.map((game) => game.id)).toEqual([
      "number-grid", "mine-logic", "nonogram", "binary-grid", "pathfinder",
      "pattern-shift", "odd-one-out", "matrix-mystery", "mirror-world",
      "flash-grid", "sequence-memory", "change-detector", "switchboard", "daily-mystery",
    ]);
  });

  it("counts consecutive completed daily dates", () => {
    const results = [
      { gameId: "daily-mystery", durationMs: 1000, score: 1, moves: 1, mistakes: 0, hintsUsed: 0, completedAt: "2026-01-03T10:00:00Z" },
      { gameId: "daily-mystery", durationMs: 1000, score: 1, moves: 1, mistakes: 0, hintsUsed: 0, completedAt: "2026-01-02T10:00:00Z" },
    ];
    expect(getDailyStreak(results, new Date("2026-01-03T12:00:00Z"))).toBe(2);
  });
});